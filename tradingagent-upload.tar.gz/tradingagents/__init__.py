# -*- coding: utf-8 -*-
"""
TradingAgents - A股智能交易代理系统
"""

__version__ = '1.0.0'