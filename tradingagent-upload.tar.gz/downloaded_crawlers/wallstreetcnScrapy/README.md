# wallstreetcnScrapy
a crawler for wallstreetcn,finance.sina by Scrapy

This is the crawler part of my graduation project which is a financial infomation search engine.<br />
It crawled three websites by using Scrapy as follows:<br />
http://wallstreetcn.com/news,<br />
http://finance.sina.com.cn/,<br />
http://news.10jqka.com.cn/<br />
then send the data to solr server to build index. And it stored the data in MySQL for backup.
